function I_comp = Compress(I)

% Your compression code goes here

I_comp.I = I; % this is just a stump to make the evaluation script run, replace it with your code!
