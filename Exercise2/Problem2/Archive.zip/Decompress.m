function I_rec = Decompress(I_comp)

% Your decompression code goes here!

I_rec = I_comp.I; % this is just a stump to make the evaluation script run, replace it with your code!