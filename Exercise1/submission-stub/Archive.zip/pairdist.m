function D = pairdist(P, Q)
D = zeros(size(P,1),size(Q,1));
end
